# ChronoTrace

Passive activity reconstruction: a Windows agent reports the foreground app/window, and the
website turns that stream into a timeline, a daily synthesis, a re-entry briefing and an AI assistant.

## Folder structure

```
chronotrace/
├── frontend/                 React 19 + Vite + Tailwind   (own package.json)
│   ├── index.html
│   ├── vite.config.ts        dev server on :5173, proxies /api -> backend :3000
│   ├── tsconfig.json
│   └── src/
│       ├── main.tsx          React entry point
│       ├── App.tsx           Screen flow + tab routing + polling
│       ├── index.css
│       ├── assets/images/
│       └── components/       One file per screen / view
│
├── backend/                  Express 4 API + session auth + JSON storage (own package.json)
│   ├── .env.example          Copy to backend/.env
│   ├── tsconfig.json
│   ├── data/                 Runtime data (git-ignored)
│   └── src/
│       ├── server.ts         Entry point: starts the server (serves frontend/dist in production)
│       ├── app.ts            Express app: middleware + route mounting
│       ├── config/env.ts     Env vars, paths, port, Gemini client
│       ├── types/models.ts   UserRecord, AuthSession, DeviceRecord
│       ├── services/
│       │   ├── userStore.ts      users.json + auth_sessions.json
│       │   ├── dataStore.ts      per-user device / telemetry / sessions / summary files
│       │   └── authHelpers.ts    session cookie lookup, profile + device-status mapping
│       └── routes/
│           ├── auth.routes.ts        /api/auth/*
│           ├── agent.routes.ts       agent download, PowerShell command, /api/ingest-event
│           ├── device.routes.ts      /api/device/*, /api/agent/status|control
│           ├── analytics.routes.ts   telemetry, sessions, summary, re-entry, patterns
│           └── ai.routes.ts          /api/assistant/chat, /api/gemini/synthesize-day
│
├── agent/                    Windows (also macOS/Linux) Python agent
│   └── chronotrace_agent.py
├── shared/                   Types used by BOTH frontend and backend
│   └── types/chronotrace.ts
├── docs/ARCHITECTURE.md      Screen flow, data flow, known issues, target design
├── archive/                  Unused code and duplicate files, kept for reference
└── package.json              Convenience scripts that run frontend + backend together
```

`frontend/` and `backend/` are independent packages: each has its own `package.json`,
`tsconfig.json` and `node_modules`. The only code they share is `shared/types`.

## Setup

Requires Node 20+ and Python 3.10+ (for the agent, standard library only).

```bash
npm install && (cd backend && npm install) && (cd frontend && npm install)
cp backend/.env.example backend/.env   # optional: GEMINI_API_KEY, GOOGLE_CLIENT_ID
npm run dev                            # app and API together on http://localhost:3000
```

For hot reload of the React app, run the API and the frontend separately. The frontend on
**:5173** forwards `/api` to the API on `PORT` (default 3000):

```bash
cd backend && npm run dev     # API on :3000
cd frontend && npm run dev    # app on :5173
```

### Sign-in setup

- **Email and password** need no configuration. Passwords need at least 8 characters, with an
  uppercase letter, a lowercase letter, a number and a special character.
- **Google sign-in** is optional. In Google Cloud Console, create an OAuth client ID of type
  "Web application" and add `http://localhost:3000` and `http://localhost:5173` under
  *Authorized JavaScript origins*. Then set `GOOGLE_CLIENT_ID` in `backend/.env` and restart the
  server. Without it, the sign-in page shows a setup message and password sign-in still works.
  The server verifies each Google ID token with Google before it creates or signs in an account.
- Set `COOKIE_SECURE=true` when the site is served over HTTPS.
- Accounts are stored in `backend/data/users.json`. If that file cannot be read, sign-in and
  registration return an error and the file is left unchanged.

### Production

```bash
npm run build            # builds the frontend into frontend/dist
npm start                # backend serves frontend/dist and the API on :3000
```

Other scripts: `npm run typecheck` (root, backend and frontend), `cd backend && npm test` (validation
and sign-in API tests, using a temporary data folder).

## Using the Windows agent

1. Sign in on the website and open the device setup screen.
2. Download the agent (`chronotrace_agent.py`) and run it with Python: `python chronotrace_agent.py`.
3. Keep it running. The site shows "Connected" once heartbeats arrive.

See `docs/ARCHITECTURE.md` for how the pieces talk to each other and what needs fixing before this is shared.
