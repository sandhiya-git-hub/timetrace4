import React from 'react';
import { ShieldCheck, CheckCircle2, XCircle, X } from 'lucide-react';

interface PrivacyModalProps {
  onClose: () => void;
}

export const PrivacyModal: React.FC<PrivacyModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4">
      <div className="bg-white border border-slate-200 rounded-2xl max-w-lg w-full p-6 sm:p-7 shadow-xl relative animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-600" />
            <h3 className="font-semibold text-slate-900 text-sm">Privacy &amp; Data Minimization</h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-4 my-4 text-xs text-slate-600 leading-relaxed">
          <p>
            ChronoTrace is engineered under strict <strong>Privacy-by-Design</strong> principles. The Windows agent acts passively and locally on your workstation to help you understand your focus and recover lost context.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80">
              <div className="flex items-center gap-1.5 font-semibold text-slate-900 mb-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>Permitted Activity</span>
              </div>
              <ul className="space-y-1 text-slate-600 text-[11px]">
                <li>· Foreground window titles</li>
                <li>· Application executable names</li>
                <li>· Active dwell duration</li>
                <li>· Aggregate typing count</li>
              </ul>
            </div>

            <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80">
              <div className="flex items-center gap-1.5 font-semibold text-slate-900 mb-2">
                <XCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>Never Collected</span>
              </div>
              <ul className="space-y-1 text-slate-600 text-[11px]">
                <li>· Keystroke text / passwords</li>
                <li>· Screen captures &amp; pixels</li>
                <li>· Webcam or microphone</li>
                <li>· Personal emails &amp; chat texts</li>
              </ul>
            </div>
          </div>

          <p className="text-[11px] text-slate-500">
            All AI synthesis uses strictly redacted summaries. Raw keystroke contents or screenshots are never generated or transmitted.
          </p>
        </div>

        <div className="flex justify-end pt-2 border-t border-slate-100">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded-lg text-xs cursor-pointer transition-colors"
          >
            I Understand
          </button>
        </div>
      </div>
    </div>
  );
};
