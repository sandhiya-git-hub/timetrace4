# ChronoTrace: how the project works

## 1. The big picture

```
 Windows PC                              Server (backend/src)                 Browser (frontend/)
 ┌──────────────────────┐   POST          ┌─────────────────────────────┐   fetch   ┌───────────────────────┐
 │ chronotrace_agent.py │ ──────────────► │ /api/ingest-event           │           │ App.tsx               │
 │ reads foreground     │  every change   │ writes data/users/<id>/*.json│ ◄──────── │ polls every 3 s       │
 │ window every 1 s     │  + every 2 s    │                             │  GET      │ /api/telemetry/raw    │
 │                      │                 │ /api/summary, /sessions ... │           │ /api/sessions         │
 │ serves 127.0.0.1:9876│ ◄───────────────│ reads the same JSON files   │           │ /api/summary/today    │
 └──────────────────────┘  polled every   └─────────────────────────────┘           │ /api/reentry/...      │
           ▲               2 s by the                  │                            └───────────────────────┘
           └── browser ────────────────────────────────┘ (see issue #5: the browser also re-posts)
```

- **Frontend**: a single-page React app. It decides which screen to show, and polls the backend.
- **Backend**: one Express server. It handles login sessions, stores per-user data in JSON files, receives agent events, computes the dashboard numbers, and calls Gemini for the AI features.
- **Agent**: a small Python program on the user's computer. It reads which window is in front and sends it to the server.

## 2. Screen flow (what the user sees, in order)

The `screen` state in `App.tsx` drives this. Each step is one file in `frontend/src/components/`.

| # | Screen (state)          | File                     | What the user does | What happens behind the scenes |
|---|-------------------------|--------------------------|--------------------|--------------------------------|
| 1 | Splash (`splash`)       | `SplashScreen.tsx`       | Clicks **Sign in** or **Reconnect** | On load, `GET /api/auth/session` decides whether a session cookie already exists. A logged-in user goes straight to step 3. |
| 2 | Sign-in (`auth`)        | `GoogleAuthScreen.tsx`   | Logs in with username/password, registers, or clicks "Google" | `POST /api/auth/login`, `/register` or `/google`. The server sets an httpOnly cookie `chronotrace_session` (30 days). |
| 3 | Device setup (`device`) | `DeviceSetupScreen.tsx`  | Copies/downloads the agent, runs it on the PC, then clicks **Continue** | `GET /api/download-agent?token=…` returns the agent with the account's device token baked in. Page polls `GET /api/device/status` until `connected: true`, then `POST /api/auth/complete-device-setup`. |
| 4 | Locked gate (`device` view) | `DeviceLockedView.tsx` | Sees this if no device has ever connected and there is no data | Blocks the dashboard until the agent has sent at least one event. |
| 5 | Main app (`app`)       | `App.tsx` + tabs below   | Uses the four tabs | Polls every 3 s (see §4). |

Inside step 5 there are four tabs, chosen in `AppHeader.tsx`:

| Tab | Component | Data it uses | Actions |
|-----|-----------|--------------|---------|
| Dashboard (`dashboard`) | `DashboardView.tsx` | `/api/summary?range=…`, `/api/sessions`, `/api/reentry/…`, `/api/telemetry/raw` | Pick a date range (`DateRangePicker`), **Refresh summary** (`POST /api/gemini/synthesize-day`), jump to the assistant with a prompt |
| Timeline (`timeline`) | `ActivityTimelineView.tsx` | `chunks` (sessions) | Correct the intent of a session: `POST /api/sessions/:id/correct` |
| Raw activity (`raw`) | `RawActivityView.tsx` | `events` (raw telemetry) | Search and filter by category |
| AI assistant (`assistant`) | `AiAssistantView.tsx` | Sends the question to `POST /api/assistant/chat` with the last messages | Ask questions about today's activity |

Other overlays: `DeviceModal` (connect/disconnect the agent from the header) and `PrivacyModal` (privacy explanation).

**Header**: `AppHeader.tsx` shows the tabs, the device status, and the logout button. Logout calls `POST /api/auth/logout` and returns to the splash.

## 3. Backend: what each part does

The backend lives in `backend/src/` (`app.ts` mounts the route files; `server.ts` starts it). The code is grouped in this order, with the route files named in brackets:

1. **Users and sessions** (`services/userStore.ts`): `users.json` (passwords as bcrypt hashes) and `auth_sessions.json`.
2. **Per-user storage** (`services/dataStore.ts`): `data/users/<userId>/` holds:
   - `device.json`: paused flag, heartbeat time, device name, agent version
   - `telemetry.json`: raw events, capped at 500
   - `sessions.json`: grouped "cognitive chunks", capped at 100
   - `summary.json`: the daily synthesis
3. **Auth routes** (`routes/auth.routes.ts`): `/api/auth/session`, `login`, `register`, `google`, `logout`, `complete-device-setup`.
4. **Agent routes** (`routes/agent.routes.ts`): `/api/download-agent` (and aliases), `/api/agent/powershell`, `/api/ingest-event` (agent data in), `/api/sync-sessions` (currently only logs).
5. **Device control** (`routes/device.routes.ts`): `/api/device/status`, `/api/device/toggle`, `/api/device/connect`, `/api/device/disconnect`, `/api/agent/status`, `/api/agent/control`.
6. **Analytics read API** (`routes/analytics.routes.ts`): `/api/telemetry/raw`, `/api/sessions`, `/api/summary`, `/api/reentry/:project`, `/api/patterns/week`, `/api/sessions/:id/correct`.
7. **AI** (`routes/ai.routes.ts`): `/api/assistant/chat` and `/api/gemini/synthesize-day`. Both send today's data to Gemini and need `GEMINI_API_KEY`.
8. **Serving the site** (`server.ts`): in dev, the frontend runs on its own Vite server (`:5173`) and proxies `/api` to Express (`:3000`). In production, Express serves `frontend/dist/` and returns `index.html` for any other path, so React routing works.

**Rule of thumb for the code**: `ingest-event` *writes* events and updates the session chunk, the daily summary and the device heartbeat. Everything else *reads* those files and returns JSON. The frontend never computes totals itself; it displays what the server returns.

## 4. Frontend: how the data loop works

`App.tsx` runs three loops:

1. **On load**: `checkAuthAndInit()` calls `/api/auth/session` and `/api/device/status`. If the user is logged in and the device has connected before, it opens the app.
2. **Every 3 s while on `app` or `device`**: `fetchAllActivityData()` fetches raw events, sessions, today's summary and the re-entry briefing, then `fetchDeviceStatus()`. The screens re-render from state.
3. **Every 2 s, always**: the browser asks the local agent at `http://127.0.0.1:9876/`. If the agent answers, the browser posts that window to `/api/ingest-event`. (See issue #5: this duplicates the agent's own posts.)

Because all data flows through these loops, the UI is effectively live with a delay of 2 to 3 seconds.

## 5. Agent: what it sends

`agent/chronotrace_agent.py` uses only the Python standard library.

- Every second it reads the active window (Windows: `ctypes` calls to `user32.GetForegroundWindow`; macOS and Linux have their own helpers).
- `parse_window_exact()` turns the app name and title into a category: `Deep Work`, `Learning`, `Communication`, `Utility`, `Entertainment`, or `Distraction`. It uses keyword lists (`PRODUCTIVE_KW`, `NON_PRODUCTIVE_KW`).
- It POSTs to `/api/ingest-event` when the window changes, and again every 2 seconds.
- It also serves its own state at `http://127.0.0.1:9876/` so the browser can read it.
- The server URL and device token are injected into the file at download time (`DEFAULT_SERVER`, `DEFAULT_USER_TOKEN`), or passed as `--token` on the command line.

## 6. Data model (shared/types/chronotrace.ts)

- `TelemetryEvent`: one reading. Fields: `timestamp`, `date`, `app_name`, `window_title`, `category`, `dwell_ms`.
- `ChunkSummary`: a session block. Groups consecutive events from the same app and category. Has `intent`, `primary_task`, `main_events`, `distraction_detected`, and `user_corrected`.
- `DailySynthesis`: the day's totals (`total_deep_work_s`, `total_distraction_s`), `fragmentation_score`, `daily_narrative`, and `distraction_triggers`.
- `DeviceState`: connection status, device name, last heartbeat, and paused flag.

## 7. How a user uses the site (end to end)

1. Open the site and click **Sign in**.
2. Log in (or register, or Google). The session cookie is set.
3. On the device page, download the agent and run `python chronotrace_agent.py` on the Windows PC. Leave the window open.
4. When the page shows the PC as connected, click **Continue**. Until data arrives, the app shows the locked view.
5. Use the computer normally. The agent records the active window; the dashboard fills in within seconds.
6. Dashboard: check focus time, distractions and the re-entry briefing ("where you left off").
7. Timeline: fix a session's intent if it was classified wrongly.
8. Raw: search events by app or title.
9. Assistant: ask "what did I spend most time on today?" and the answer is grounded in the stored data.
10. Pause collection from the device modal at any time. The agent's next post gets a `409 paused` response.

## 8. Issues found while restructuring (verified)

Items marked **verified** were reproduced by running the server or the build. The rest were found by reading the code.

| # | Severity | Issue | Where | Status |
|---|----------|-------|-------|--------|
| 1 | Critical | **Seeded accounts with fixed passwords** (`sandhiya`/`password123`, `admin`/`adminpassword`). The sign-in form is pre-filled with the first one. | `backend/src/services/userStore.ts` `getInitialUsers`, `GoogleAuthScreen.tsx` | Not changed. Needs a decision (see below). |
| 2 | Critical | **Data endpoints fall back to the first user when there is no session.** An anonymous request reads that user's device status, and can call `/api/device/toggle` to pause their agent. | `getAuthenticatedUser(req) \|\| getDefaultUser()` at 17 call sites | **Verified**: anonymous `GET /api/device/status` returned the account's device record. |
| 3 | Critical | **The device token is handed out without login.** `/api/download-agent` and `/api/agent/powershell` return the token. Anyone who has it can write events into that account. | `sendAgentScript`, `/api/agent/powershell` | **Verified**: an unauthenticated download contained `DEFAULT_USER_TOKEN = "ct_dev_sandhiya_live9876"`. |
| 4 | High | **"Continue with Google" is fake.** The button posts a hard-coded profile (`sandhiyasankarpersonal@gmail.com`). The server trusts the body if no Google credential is sent, so anyone can sign in as that email. | `GoogleAuthScreen.tsx`, `/api/auth/google` | Code-verified. |
| 5 | High | **Every window is counted twice.** The agent POSTs to `/api/ingest-event`, and the browser also polls the agent and POSTs again. Each post adds 2 s, so time is inflated about 2x. | `agent.py` `poll_os_loop`, `App.tsx` bridge effect | **Verified** on the server: two posts = two events (4 s recorded for 2 s of real time). |
| 6 | High | **Locked PC keeps accruing time.** The agent does not clear its last window when it cannot read one (e.g. lock screen), so the browser keeps posting that app. | `agent.py` `current_state` | Code-verified. |
| 7 | Medium | **Data was stored in the OS temp folder** (`os.tmpdir()`), so it could be wiped on reboot. | `backend/src/config/env.ts` `DATA_DIR` | **Fixed** in the restructure: default is `backend/data/`. |
| 8 | Medium | **`npm install` failed** (peer conflict between `vite@8` and `esbuild@0.25`). | `package.json` | **Fixed**: removed the unused `esbuild` and `motion`. Plain `npm install` now works. |
| 9 | Medium | **Six screens are dead code** and call endpoints that do not exist (`/api/user/settings`, `/api/user/profile`, `/api/data/export`, `/api/data/clear`, `/api/gemini/ask`). | `components/*Page.tsx` | Moved to `archive/unused-frontend-pages/`. |
| 10 | Medium | **Four copies of the agent** plus cached `.pyc` files. Only one is served. | root, `public/`, `__pycache__` | Consolidated to `agent/chronotrace_agent.py`; copies in `archive/duplicates/`. |
| 11 | Low | **Every request reads and rewrites whole JSON files.** Fine for one user, but it breaks under concurrency and will not scale. | `get/saveUser*` helpers | Not changed. |
| 12 | Low | `/api/reentry/:project` ignores the `:project` parameter. `/api/sync-sessions` only logs. Gemini model `gemini-3.8-flash` is hard-coded; check that it is a valid model ID for your key. | `backend/src/routes/*` | Not changed. |
| 13 | Note | The agent records window titles, which often contain document names, email subjects and chat names. Check that `PrivacyModal` says this clearly. | `agent.py`, `PrivacyModal.tsx` | Note only. |

## 9. How I would design it (target flow)

**Screens**: Splash → Sign in → Pair your PC → Waiting for first data → Dashboard (tabs: Today, Timeline, Activity, Assistant, Settings).

**Changes I would make, in order:**

1. **Remove seeded credentials.** Create the first admin with a setup step, or from an environment variable. Never ship a fixed password.
2. **Require a session on every `/api/*` route.** Replace `|| getDefaultUser()` with a `requireUser` middleware that returns 401.
3. **Pair the PC with a one-time code, not the account token.** The website shows a 6-character code. The agent runs with `--pair CODE` and receives its own device credential, which the server stores hashed. The download no longer contains a secret.
4. **Use real Google sign-in** (Google Identity Services) and verify the ID token on the server with Google's library.
5. **One ingest path.** Remove the browser bridge. The agent is the only writer. Give each event an ID so the server can drop duplicates.
6. **Clear the window when the PC is locked or idle**, and send an explicit `idle` event so time is not counted as work.
7. **Move storage to SQLite** (one `events` table with indexes on user and time). Compute totals with queries instead of rewriting JSON files.
8. **Privacy settings**: a toggle to store window titles or only the app name, a visible pause button, and a "delete my data" action (which the dead Settings page was meant to provide).

## 10. Running it

See `README.md`. Setup: `npm run install:all`, then `npm run dev` (open :5173). Production: `npm run build`, then `npm start`.
