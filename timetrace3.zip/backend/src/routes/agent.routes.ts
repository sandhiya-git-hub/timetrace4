import express from 'express';
import bcrypt from 'bcryptjs';
import path from 'path';
import fs from 'fs';
import { ai, AGENT_FILE } from '../config/env.js';
import type { ChunkSummary, DailySynthesis, TelemetryEvent, DeviceState } from '../../../shared/types/chronotrace.js';
import type { UserRecord, AuthSession, DeviceRecord } from '../types/models.js';
import { getUsers, saveUsers, getAuthSessions, saveAuthSessions } from '../services/userStore.js';
import { getUserDir, defaultDeviceRecord, HEARTBEAT_TIMEOUT_MS, isAgentLive, getUserDeviceRecord, saveUserDeviceRecord, getUserTelemetry, saveUserTelemetry, getUserSessions, saveUserSessions, getUserSummary, saveUserSummary } from '../services/dataStore.js';
import { getSessionToken, getAuthenticatedUser, createSessionForUser, toUserProfile, toDeviceStatus } from '../services/authHelpers.js';

const router = express.Router();

// -------------------------------------------------------------
// WINDOWS AGENT COLLECTION SCRIPT & POWERSHELL COMMAND
// -------------------------------------------------------------

// The agent identifies itself with its own device token (body, X-User-Token header
// or Bearer). Nothing else is accepted, and there is no default-user fallback.
// The agent identifies itself with its own device token (header, bearer, body, or query).
function resolveTargetUserForAgent(req: express.Request): UserRecord | null {
  const auth = req.headers['authorization'];
  const bearer = typeof auth === 'string' && auth.startsWith('Bearer ') ? auth.substring(7).trim() : null;
  const headerTok = req.headers['x-device-token'] || req.headers['x-user-token'];
  const candidate =
    req.body?.deviceToken ||
    req.body?.userToken ||
    (typeof headerTok === 'string' ? headerTok : null) ||
    (typeof req.query?.token === 'string' ? req.query.token : null) ||
    bearer;
  if (!candidate || typeof candidate !== 'string') return null;
  return getUsers().find((u) => u.deviceToken === candidate) || null;
}

const sendAgentScript = (req: express.Request, res: express.Response) => {
  try {
    const agentFilePath = AGENT_FILE;
    let code = fs.readFileSync(agentFilePath, 'utf-8');

    let proto = (req.headers['x-forwarded-proto'] as string) || req.protocol || 'https';
    const host = (req.headers['x-forwarded-host'] as string) || req.get('host') || 'localhost:3000';
    if (host.includes('.run.app') || host.includes('aistudio')) {
      proto = 'https';
    }
    const computedOrigin = `${proto}://${host}`;
    const hostUrl = process.env.APP_URL ? process.env.APP_URL.replace(/\/+$/, '') : computedOrigin;

    let user = res.locals.user as UserRecord | undefined;
    if (!user && req.query.token) {
      const qToken = String(req.query.token).trim();
      user = getUsers().find((u) => u.deviceToken === qToken);
    }
    if (!user) {
      user = getAuthenticatedUser(req);
    }
    const deviceToken = user ? user.deviceToken : (typeof req.query.token === 'string' ? String(req.query.token).trim() : '');

    code = code.replace(
      /DEFAULT_SERVER\s*=\s*["'][^"']+["']/,
      `DEFAULT_SERVER = "${hostUrl}"`
    );

    code = code.replace(
      /DEFAULT_USER_TOKEN\s*=\s*["'][^"']*["']/,
      `DEFAULT_USER_TOKEN = "${deviceToken}"`
    );

    res.setHeader('Content-Type', 'text/x-python; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="chronotrace_agent.py"');
    res.send(code);
  } catch (e: any) {
    console.error('Error serving agent script:', e);
    res.status(500).send('# Error serving agent script: ' + (e?.message || 'unknown error'));
  }
};

router.get([
  '/api/download-agent',
  '/api/download/chronotrace_agent.py',
  '/download/chronotrace_agent.py',
  '/agent.py',
  '/chronotrace_agent.py',
  '/api/agent.py',
  '/api/chronotrace_agent.py',
  '/public/agent.py',
  '/public/chronotrace_agent.py',
], sendAgentScript);

router.get('/api/agent/powershell', (req, res) => {
  let proto = (req.headers['x-forwarded-proto'] as string) || req.protocol || 'https';
  const host = (req.headers['x-forwarded-host'] as string) || req.get('host') || 'localhost:3000';
  if (host.includes('.run.app') || host.includes('aistudio')) {
    proto = 'https';
  }
  const appOrigin = process.env.APP_URL ? process.env.APP_URL.replace(/\/+$/, '') : `${proto}://${host}`;
  const user = res.locals.user as UserRecord;

  const script = `cd "$env:USERPROFILE\\Downloads"; python chronotrace_agent.py`;
  res.json({ script, origin: appOrigin, deviceToken: user.deviceToken });
});

// -------------------------------------------------------------
// LIVE INGESTION FROM WINDOWS AGENT
// -------------------------------------------------------------

function ingestSingleEvent(
  user: UserRecord,
  payload: any,
  deviceRec: DeviceRecord,
  telemetry: TelemetryEvent[],
  sessions: ChunkSummary[],
  summary: DailySynthesis
): { ingested: boolean; duplicate: boolean } {
  const eventId = payload.id || `evt_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;

  // Deduplicate against existing telemetry IDs
  const alreadyExists = telemetry.some((e) => e.id === eventId);
  if (alreadyExists) {
    return { ingested: false, duplicate: true };
  }

  const nowIso = payload.utcTimestamp || payload.recorded_at || new Date().toISOString();
  const nowTime =
    payload.localTime ||
    new Date(nowIso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const nowDate = payload.localDate || new Date(nowIso).toISOString().split('T')[0];

  const deltaSec = Math.max(1, Number(payload.deltaSeconds || payload.durationSeconds) || 2);
  const appName = (payload.appName || 'Active Window').trim();
  const winTitle = (payload.windowTitle || appName).trim();
  const cat = payload.overrideCategory || payload.category || 'Deep Work';
  const task = payload.overrideTask || payload.specificTask || `Active in ${appName}`;

  const newEvent: TelemetryEvent = {
    id: eventId,
    timestamp: nowTime,
    date: nowDate,
    recorded_at: payload.recorded_at || payload.localTimestamp || nowIso,
    dwell_ms: deltaSec * 1000,
    category: cat,
    app_name: appName,
    window_title: winTitle,
    keyboard_events: 0,
  };

  telemetry.push(newEvent);
  if (telemetry.length > 500) telemetry.shift();

  deviceRec.lastEventTime = nowTime;
  deviceRec.lastLocalDate = nowDate;

  // Session chunk reconstruction
  const lastSession = sessions[sessions.length - 1];
  let intent: any = 'DEEP_WORK';
  if (cat === 'Learning') intent = 'LEARNING';
  else if (cat === 'Entertainment' || cat === 'Distraction') intent = 'DISTRACTION';
  else if (cat === 'Communication') intent = 'COMMUNICATION';
  else if (cat === 'Utility') intent = 'ADMIN';

  if (
    lastSession &&
    lastSession.anchor_app?.toLowerCase() === appName.toLowerCase() &&
    lastSession.dominant_category === cat
  ) {
    lastSession.duration_s += deltaSec;
    lastSession.end_time = nowTime;
    const sub = lastSession.main_events?.find((m) => m.title === winTitle);
    if (sub) {
      sub.dwell_s += deltaSec;
    } else if (lastSession.main_events) {
      lastSession.main_events.push({ app: appName, title: winTitle, dwell_s: deltaSec, keys: 0 });
    }
    lastSession.summary = `User active in ${appName}: ${winTitle} (${Math.round(lastSession.duration_s)}s duration).`;
  } else {
    const chunkId = `live_${Date.now()}_${sessions.length + 1}`;
    const newChunk: ChunkSummary = {
      chunk_id: chunkId,
      recorded_at: payload.recorded_at || payload.localTimestamp || nowIso,
      duration_s: deltaSec,
      start_time: nowTime,
      end_time: nowTime,
      closed_by: 'CATEGORY_SHIFT',
      main_events: [{ app: appName, title: winTitle, dwell_s: deltaSec, keys: 0 }],
      anchor_app: appName,
      anchor_held_s: deltaSec,
      returned_to_anchor: true,
      keyboard: { total_keys: 0, rate_per_min: 0 },
      micro_behavior: {
        total_rapid_switches: 1,
        tab_flickers: 0,
        avg_micro_dwell_ms: deltaSec * 1000,
        dominant_pattern: 'NORMAL',
        unique_micro_apps: [appName],
      },
      categories_present: [cat],
      dominant_category: cat,
      copy_paste_events: 0,
      session_start_restless: false,
      intent,
      confidence: 0.95,
      primary_task: task,
      distraction_detected: cat === 'Entertainment' || cat === 'Distraction',
      distraction_type: cat === 'Entertainment' || cat === 'Distraction' ? 'rabbit_hole' : null,
      work_state: cat === 'Deep Work' || cat === 'Learning' ? 'productive' : 'settled',
      unresolved_threads: [],
      summary: `Reconstructed passive activity: ${appName} - ${winTitle} (${deltaSec}s dwell).`,
    };
    sessions.push(newChunk);
    if (sessions.length > 100) sessions.shift();
  }

  // Update Daily Synthesis
  summary.date = nowDate;
  summary.total_telemetry_s = (summary.total_telemetry_s || 0) + deltaSec;
  if (cat === 'Deep Work' || cat === 'Learning') {
    summary.total_deep_work_s = (summary.total_deep_work_s || 0) + deltaSec;
  } else if (cat === 'Entertainment' || cat === 'Distraction') {
    summary.total_distraction_s = (summary.total_distraction_s || 0) + deltaSec;
    if (winTitle) {
      if (!summary.distraction_triggers) summary.distraction_triggers = [];
      if (!summary.distraction_triggers.includes(winTitle.slice(0, 45))) {
        summary.distraction_triggers.push(winTitle.slice(0, 45));
      }
    }
  }

  return { ingested: true, duplicate: false };
}

router.post('/api/ingest-event', (req, res) => {
  try {
    const user = resolveTargetUserForAgent(req);
    if (!user) {
      return res.status(401).json({ error: 'Unrecognized device token. Device not bound to any user account.' });
    }

    const deviceRec = getUserDeviceRecord(user.id);
    if (deviceRec.paused) {
      return res.status(409).json({
        status: 'paused',
        received: false,
        message: 'Activity collection is currently paused on the website.',
      });
    }

    const payload = req.body || {};
    const nowIso = payload.utcTimestamp || new Date().toISOString();

    // Mark heartbeat
    if (!isAgentLive(deviceRec, Date.parse(nowIso))) {
      deviceRec.connectedSince = nowIso;
    }
    deviceRec.lastHeartbeatAt = nowIso;
    deviceRec.lastSuccessfulConnectionAt = nowIso;

    if (payload.deviceName) deviceRec.deviceName = payload.deviceName;
    if (payload.os) deviceRec.os = payload.os;
    if (payload.agentVersion) deviceRec.agentVersion = payload.agentVersion;
    if (payload.timezoneOffsetMinutes !== undefined) deviceRec.timezoneOffsetMinutes = payload.timezoneOffsetMinutes;
    if (payload.timezoneName) deviceRec.timezoneName = payload.timezoneName;

    // Heartbeat-only signal
    if (payload.heartbeat && !payload.appName && !payload.events) {
      saveUserDeviceRecord(user.id, deviceRec);
      return res.json({ status: 'ok', received: true, heartbeat: true, user: user.username });
    }

    const telemetry = getUserTelemetry(user.id);
    const sessions = getUserSessions(user.id);
    const summary = getUserSummary(user.id);

    let ingestedCount = 0;
    let duplicateCount = 0;

    // Check if batch of events was provided (e.g. from local offline queue)
    if (Array.isArray(payload.events) && payload.events.length > 0) {
      for (const ev of payload.events) {
        if (!ev.appName && !ev.windowTitle) continue;
        const resIngest = ingestSingleEvent(user, ev, deviceRec, telemetry, sessions, summary);
        if (resIngest.ingested) ingestedCount++;
        if (resIngest.duplicate) duplicateCount++;
      }
    } else if (payload.appName) {
      const resIngest = ingestSingleEvent(user, payload, deviceRec, telemetry, sessions, summary);
      if (resIngest.ingested) ingestedCount++;
      if (resIngest.duplicate) duplicateCount++;
    }

    saveUserTelemetry(user.id, telemetry);
    saveUserSessions(user.id, sessions);
    saveUserSummary(user.id, summary);
    saveUserDeviceRecord(user.id, deviceRec);

    return res.json({
      status: 'ok',
      received: true,
      ingested: ingestedCount,
      duplicates: duplicateCount,
      totalEvents: telemetry.length,
      user: user.username,
      chunkCount: sessions.length,
    });
  } catch (e: any) {
    console.error('Error in ingest-event:', e);
    return res.status(500).json({ error: e.message });
  }
});

// Sync full sessions or chronotrace_live.json payload from agent
router.post(['/api/sync-sessions', '/api/agent/sync-file'], (req, res) => {
  try {
    const user = resolveTargetUserForAgent(req);
    if (!user) {
      return res.status(401).json({ error: 'Unrecognized user token. Device not bound to any account.' });
    }

    const payload = req.body || {};
    let inputSessions: any[] = Array.isArray(payload.sessions)
      ? [...payload.sessions]
      : Array.isArray(payload)
      ? [...payload]
      : [];

    // Also include currently active window if present and valid
    if (payload.current && payload.current.appName && payload.current.appName !== 'Waiting...') {
      const cur = payload.current;
      const curTitle = cur.windowTitle || cur.appName;
      const isAlreadyLast = inputSessions.length > 0 &&
        inputSessions[inputSessions.length - 1].appName === cur.appName &&
        inputSessions[inputSessions.length - 1].windowTitle === curTitle;

      if (!isAlreadyLast) {
        inputSessions.push({
          id: `cur-${Date.now()}`,
          appName: cur.appName,
          windowTitle: curTitle,
          category: cur.category || 'Deep Work',
          specificTask: cur.specificTask || `${cur.appName}: ${curTitle}`,
          durationSeconds: Math.max(1, Number(cur.elapsedSeconds) || 2),
          startTime: new Date(cur.timestamp ? cur.timestamp * 1000 : Date.now()).toLocaleTimeString(),
          endTime: new Date().toLocaleTimeString(),
        });
      }
    }

    const nowIso = new Date().toISOString();
    const nowDate = new Date().toISOString().split('T')[0];
    const rec = getUserDeviceRecord(user.id);
    rec.lastHeartbeatAt = nowIso;
    rec.lastSuccessfulConnectionAt = nowIso;
    rec.connectedSince = rec.connectedSince || nowIso;
    rec.paused = false;

    if (payload.deviceName) rec.deviceName = payload.deviceName;
    if (payload.os) rec.os = payload.os;

    if (inputSessions.length > 0) {
      const telemetry = getUserTelemetry(user.id);
      const existingChunks = getUserSessions(user.id);
      const summary = getUserSummary(user.id);

      inputSessions.forEach((s: any) => {
        const appName = s.appName || 'Application';
        const winTitle = s.windowTitle || appName;
        const cat = s.category || 'Deep Work';
        const task = s.specificTask || s.inferredIntent || `${appName}: ${winTitle}`;
        const dwellS = Math.max(1, Number(s.durationSeconds) || 2);
        const startTimeStr = s.startTime || new Date().toLocaleTimeString();
        const endTimeStr = s.endTime || startTimeStr;

        // Deduplication key
        const matchChunk = existingChunks.find(
          (c) =>
            (s.id && c.chunk_id === s.id) ||
            (c.anchor_app === appName && c.start_time === startTimeStr) ||
            (c.main_events?.length === 1 &&
              c.main_events[0].app === appName &&
              c.main_events[0].title === winTitle &&
              c.start_time === startTimeStr)
        );

        if (matchChunk) {
          // Update existing chunk with latest duration
          matchChunk.duration_s = dwellS;
          matchChunk.anchor_held_s = dwellS;
          matchChunk.end_time = endTimeStr;
          if (matchChunk.main_events && matchChunk.main_events[0]) {
            matchChunk.main_events[0].dwell_s = dwellS;
          }
          matchChunk.summary = `Captured session: ${appName} - ${winTitle} (${dwellS}s).`;
        } else {
          // New chunk
          const chunkId = s.id || `chk_sync_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
          existingChunks.push({
            chunk_id: chunkId,
            recorded_at: nowIso,
            duration_s: dwellS,
            start_time: startTimeStr,
            end_time: endTimeStr,
            closed_by: 'NATURAL_SWITCH',
            main_events: [{ app: appName, title: winTitle, dwell_s: dwellS, keys: 0 }],
            anchor_app: appName,
            anchor_held_s: dwellS,
            returned_to_anchor: true,
            keyboard: { total_keys: 0, rate_per_min: 0 },
            micro_behavior: {
              total_rapid_switches: 1,
              tab_flickers: 0,
              avg_micro_dwell_ms: dwellS * 1000,
              dominant_pattern: 'NORMAL',
              unique_micro_apps: [appName],
            },
            categories_present: [cat],
            dominant_category: cat,
            copy_paste_events: 0,
            session_start_restless: false,
            intent: (cat === 'Deep Work' ? 'CODING' : cat === 'Learning' ? 'LEARNING' : cat === 'Entertainment' ? 'DISTRACTION' : 'UTILITY') as any,
            confidence: 0.95,
            primary_task: task,
            distraction_detected: cat === 'Entertainment' || cat === 'Distraction',
            distraction_type: null,
            work_state: cat === 'Deep Work' || cat === 'Learning' ? 'productive' : 'settled',
            unresolved_threads: [],
            summary: `Captured session: ${appName} - ${winTitle} (${dwellS}s).`,
          });

          // Add raw telemetry event
          telemetry.push({
            id: `evt_sync_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
            timestamp: startTimeStr,
            date: nowDate,
            recorded_at: nowIso,
            dwell_ms: dwellS * 1000,
            category: cat,
            app_name: appName,
            window_title: winTitle,
            keyboard_events: 0,
          });
        }
      });

      // Recalculate summary metrics from the deduplicated chunks
      let totalTele = 0;
      let totalDeep = 0;
      let totalDist = 0;
      const triggers: Set<string> = new Set();

      existingChunks.forEach((c) => {
        totalTele += c.duration_s || 0;
        if (c.dominant_category === 'Deep Work' || c.dominant_category === 'Learning') {
          totalDeep += c.duration_s || 0;
        } else if (c.dominant_category === 'Entertainment' || c.dominant_category === 'Distraction') {
          totalDist += c.duration_s || 0;
          if (c.primary_task) triggers.add(c.primary_task);
        }
      });

      summary.total_telemetry_s = totalTele;
      summary.total_deep_work_s = totalDeep;
      summary.total_distraction_s = totalDist;
      summary.distraction_triggers = Array.from(triggers);

      if (telemetry.length > 500) telemetry.splice(0, telemetry.length - 500);
      if (existingChunks.length > 100) existingChunks.splice(0, existingChunks.length - 100);

      rec.lastEventTime = new Date().toLocaleTimeString();
      rec.lastLocalDate = nowDate;

      saveUserTelemetry(user.id, telemetry);
      saveUserSessions(user.id, existingChunks);
      saveUserSummary(user.id, summary);
    }

    saveUserDeviceRecord(user.id, rec);
    const telemetry = getUserTelemetry(user.id);
    res.json({
      success: true,
      device: toDeviceStatus(rec, telemetry.length),
      syncedSessions: inputSessions.length,
      totalEvents: telemetry.length,
    });
  } catch (err: any) {
    res.status(500).json({ error: err?.message || 'Error syncing sessions' });
  }
});


export default router;
