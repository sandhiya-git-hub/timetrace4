export interface UserRecord {
  id: string;             // unique identifier e.g. usr_1728690000_abc
  username: string;       // unique lowercase username
  email: string;          // unique lowercase email
  passwordHash: string;   // bcrypt hash
  name: string;           // display name
  givenName: string;
  picture?: string;
  deviceToken: string;    // unique token for the Windows agent
  googleSub?: string;
  createdAt: string;
  lastLogin: string;
  isRegistered?: boolean;
  hasConfiguredDevice?: boolean;
}

export interface AuthSession {
  token: string;
  userId: string;
  createdAt: string;
  expiresAt: string;
}

export interface DeviceRecord {
  paused: boolean;
  deviceName: string;
  os: string;
  agentVersion: string;
  samplingInterval: string;
  lastHeartbeatAt: string | null;
  connectedSince: string | null;
  lastSuccessfulConnectionAt: string | null;
  lastEventTime: string | null;
  lastLocalDate?: string | null;
  timezoneOffsetMinutes?: number;
  timezoneName?: string;
}
